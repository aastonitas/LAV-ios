#import <UIKit/UIKit.h>
#import <XCTest/XCTest.h>

@interface WebViewTests : XCTestCase

@end

@implementation WebViewTests

- (void)setUp {
    [super setUp];
}

- (void)tearDown {
    [super tearDown];
}

- (void)testExample {
    XCTAssert(YES, @"Pass");
}

- (void)testPerformanceExample {
    [self measureBlock:^{
    }];
}

@end