//
//  OnlineAppCreator.com
//  WebViewGold 3.6 (Objective-C)
//

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

